-- Seed additional roles for extended access control
INSERT IGNORE INTO roles(name) VALUES ('manager'), ('accountant');

