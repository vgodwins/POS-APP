<?php
// Root front controller fallback for environments where the document root points to the repo root.
require __DIR__ . '/public/index.php';